Hammock
=======

If you're looking for a modern server-side replacement for Hammock, you can try:

http://github.com/danielcrenna/hammock2

If you need legacy support and System.Web namespace usage, then you'll want:

http://github.com/restsharp/restsharp


Sunset Notice
-------------
I'm really glad if this project was/is helpful for your development.

But I wouldn't count on any updates. 

Patches that can merge cleanly are always welcome.

For everything else, there's a fork button.
